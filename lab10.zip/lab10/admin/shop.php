<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admincss.css">
    <title>Kategorie | Sklep</title>
</head>
<body>
<?php
// Dodanie parametrów z pliku cfg.php w celu połączenia z bazą danych
require('cfg.php');

function DodajKategorie() {
    $wynik = '<h3>Dodaj kategorię:</h3>'.'<form method="POST" action="add_category.php">';
    $wynik .= 'Matka: <input class="tytul" type="text" name="mother" value=""><br /> <br />';
    $wynik .= 'Nazwa: <input class="tytul" type="text" name="name" value=""><br /> <br />';
    $wynik .= '<input class="zapisz" type="submit" value="Dodaj">'.'</form>';
    
    return $wynik;
}

function UsunKategorie() {
    global $link;

    // Odszukanie podstrony o podanym id lub wyświetlenie komunikatu o braku podstrony
    if (isset($_GET['id'])) {
        $id = htmlspecialchars($_GET['id']);
    } else {
        echo "Nie znaleziono podstrony o podanym ID";
        exit;
    }

    // Usunięcie kategorii z bazy danych
    $query = "DELETE FROM shop WHERE id = $id LIMIT 1";
    $result = mysqli_query($link, $query);

    // Wyświetlenie komunikatu o usunięciu kategorii lub o błędzie
    if ($result) {
        echo "Pomyślnie usunięto kategorię";
        header("Location: shop.php");
    } else {
        echo "Błą podczas usuwania kategorii";
        exit;
    }
}

function EdytujKategorie() {
    global $link;

    // Ustalenie id kategorii lub wuświetlenie informacji o braku kategorii z podanym id
    if (isset($_GET['id'])) {
        $id = htmlspecialchars($_GET['id']);
    } else {
        echo "Nie znaleziono kategorii o podanym ID";
        exit;
    }

    // Pobranie danych kategorii z bazy danych
    $query = "SELECT matka, nazwa FROM shop WHERE id = '$id'";
    $result = mysqli_query($link, $query);

    // Przypisanie danych kategorii do zmiennych
    if (mysqli_num_rows($result) > 0 && $result) {
        $row = mysqli_fetch_assoc($result);
        $matka = $row['matka'];
        $nazwa = $row['nazwa'];

        // Stworzenie formularza do edycji kategorii
        $wynik = '<h3>Edycja Kategorii o id:'.$id.'</h3>'.'<form method="POST" action="save_edit_category.php?id='.$id.'">';
        $wynik .= '<input class="tytul" type="text" name="mother" value="'.$matka.'"><br />';
        $wynik .= '<input class="tytul" type="text" name="name" value="'.$nazwa.'"><br />';
        $wynik .= '<input class="zapisz" type="submit" name="zapisz" value="zapisz">'.'</form>';

        return $wynik;
    }
}

function PokazKategorie() {
    global $link;

    $wynik = '<h3>Kategorie:</h3>' . '<ul class="kategorie">';
    $wynik .= '<li><a href="' . $_SERVER['PHP_SELF'] . '?action=dodaj">Dodaj Kategorię</a></li>';

    // Pobranie danych z bazy danych
    $query = "SELECT id, matka, nazwa FROM shop ORDER BY matka, id";
    $result = mysqli_query($link, $query);

    // Sprawdzenie czy zapytanie zwróciło wyniki
    if ($result && mysqli_num_rows($result) > 0) {
        $kategorie = array(); // Tablica przechowująca informacje o podkategoriach
        $matki = array(); // Tablica przechowująca informacje o kategoriach

        // Iteracja po wynikach zapytania
        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
            $matka = $row['matka'];
            $nazwa = $row['nazwa'];

            // Dodanie informacji o kategoriach i podkategoriach
            if ($matka == 0) {
                $matki[$id] = array('nazwa' => $nazwa, 'id' => $id, 'podkategorie' => array());
            } else {
                $kategorie[$id] = array('nazwa' => $nazwa, 'id' => $id, 'matka' => $matka);
                $matki[$matka]['podkategorie'][] = &$kategorie[$id]; // Przypisanie podkategorii do odpowiedniej kategorii
            }
        }

        // Wyświetlenie kategorii i podkategorii z pętlą zagnieżdżoną
        foreach ($matki as $matka) {
            $wynik .= '<br /><li>ID: '. $matka['id'].' <span style="font-size: 1.6em; margin-bottom: 20px; font-weight: bold;">'. $matka['nazwa'] . '</span>' . '    <a href="' . $_SERVER['PHP_SELF'] . '?action=edytuj&id=' . $matka['id'] . '">Edytuj</a> | <a href="' . $_SERVER['PHP_SELF'] . '?action=usun&id=' . $matka['id'] . '">Usuń</a></li>';
            $wynik .= '<ul>';

            // Pętla zagnieżdżona do wyświetlenia podkategorii
            foreach ($matka['podkategorie'] as $podkategoria) {
                $wynik .= '<li>ID: '. $podkategoria['id'].' ' .' <span style="font-size: 1.3em; margin-bottom: 20px;">'. $podkategoria['nazwa'] . '</span>' . '    <a href="' . $_SERVER['PHP_SELF'] . '?action=edytuj&id=' . $podkategoria['id'] . '">Edytuj</a> | <a href="' . $_SERVER['PHP_SELF'] . '?action=usun&id=' . $podkategoria['id'] . '">Usuń</a></li>';
            }

            $wynik .= '</ul></li>';
        }

    } else {
        // Wyświetlenie komunikatu o braku kategorii
        $wynik .= '<li style="font-size:1.6em">Brak kategorii</li>';
    }

    $wynik .= '</ul>';

    echo $wynik;

    // Wykonanie odpowiedniej akcji w zależności od parametru $_GET['action']
    if (isset($_GET['action'])) {
        $action = htmlspecialchars($_GET['action']);
        if ($action === 'edytuj' && isset($_GET['id'])) {
            echo EdytujKategorie();
        } else if ($action === 'usun' && isset($_GET['id'])) {
            echo UsunKategorie();
        } else if ($action === 'dodaj') {
            echo DodajKategorie();
        }
    }
}

echo PokazKategorie();

?>

</body>
</html>